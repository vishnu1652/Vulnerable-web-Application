
<?php

    $EMAIL = $_POST['mail']; 
  $password1 = $_POST['pwd'];  
  
      
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "buggy";  
    

    $conn = mysqli_connect($host, $user, $password, $db_name);  
  
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "Select *from sign where email='$EMAIL' and Password='$password1'";
$res=mysqli_query($conn, $sql);

$count=mysqli_fetch_assoc($res);

if($count > 0){
	
	if($EMAIL==admin){
	echo "login successfull";
	header("Location:admin.php");
		
	}
	else{
		
		header("Location:index2.php");
	}
}
	
else{
 
	echo "invalid user name and password";
	
	
}
print_r($res);
    ?>





